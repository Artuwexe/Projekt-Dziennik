const data = document.querySelector("#data");
const form = document.querySelector("form");
const display = document.querySelector(".display");
const dzial = document.querySelector("#dzial");
const Spraw = document.querySelector("#Spraw");
const imie = document.querySelector("#imie");
const nazwisko = document.querySelector("#nazwisko");
const klasa = document.querySelector("#klasa");
const podpiecie = document.querySelector(".podpiecie");
let i = 0;
form.addEventListener("submit", function (evt) {
  evt.preventDefault();
  const element = document.createElement(imie.value);
  element.innerHTML = imie.value + " " + nazwisko.value + " " + klasa.value;
  element.style.fontSize = "2rem";
  const pod = document.createElement(data.value);
  // element.addEventListener("click", function () {
  // this.remove(); //this oznacza nadrzędny element, czyli formularz
  // });
  element.addEventListener("click", (evt) => {
    evt.currentTarget.remove();
  });
  display.append(element); //podpięcie
});
